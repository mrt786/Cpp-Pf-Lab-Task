#include<iostream>
using namespace std;
int main(){
    float simple_interest;
    int principle,rate,_time;
    cout<<"enter the principle";
    cin>>principle;
    cout<<"enter time";
    cin>>_time;
    cout<<"enter rate";
    cin>>rate;
    simple_interest=(principle*rate*_time);
    simple_interest=simple_interest/100;
    cout<<"the simple interest is"<<simple_interest;
    return 0;
}
