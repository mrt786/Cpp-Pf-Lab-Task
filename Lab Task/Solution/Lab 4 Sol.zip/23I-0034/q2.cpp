#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int x1,x2,y1,y2,z1,z2;
	float distance;
	cout<<"enter x1:";
	cin>>x1;
	cout<<"enter x2:";
	cin>>x2;
	cout<<"enter y1:";
	cin>>y1;
	cout<<"enter y2:";
	cin>>y2;
	z1=(x2-x1)*(x2-x1);
	//distance=sqrt((x2 – x1)² + (y2 – y1)²)
	z2=(y2-y1)*(y2-y1);
	distance=sqrt(z1+z2);
	cout<<distance;
	return 0;
}
