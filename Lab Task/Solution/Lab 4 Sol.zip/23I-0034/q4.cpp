#include<iostream>
using namespace std;
int main(){
    float a,b;
    cout<<"enter a:";
    cin>>a;
    cout<<"enter b:";
    cin>>b;
    a=a/b;
    b=a*b;
    a=b/a;
    cout<<"the value of a after swapping is:"<<a;
    cout<<"the value of b after swapping is"<<b;
    return 0;
}  
