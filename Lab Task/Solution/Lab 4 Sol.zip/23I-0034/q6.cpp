#include<iostream>
using namespace std;
int main(){
    float celsius;
    int fahrenheit;
    cout<<"take temperature as farenheit";
    cin>>fahrenheit;
    celsius=(fahrenheit-32)*(5/9);
    cout<<"the temperature in celsius"<<celsius;
    return 0;
}
