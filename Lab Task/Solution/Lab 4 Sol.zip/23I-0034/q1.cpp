#include<iostream>
using namespace std;
int main(){
	char a,b,c;// c is the third variable for swapping 
	cout<<"enter characters:";
	cin>>a;
	cout<<"enter 2nd character:";
	cin>>b;	
	c=a;
	a=b;
	b=c;
	cout<<"the vairables after sawpping are"<<"a="<<a<<"\nb="<<b;
	return 0;
}
