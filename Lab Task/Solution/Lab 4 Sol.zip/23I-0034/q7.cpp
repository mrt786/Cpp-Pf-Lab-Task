#include<iostream>
#include<cmath>
using namespace std;
int main(){
	    float a1,a2,a3;/*a1 is the are of reactngle ,a2 is the area of square,a3 is the area of triangle*/
	    //for area of rectangle 
	   /int l,w;// l=length,w=width
	    cout<<"enter length:";
	    cin>>l;
	    cout<<"enter width:";
	    cin>>w;
	    a1=l*w;
	    cout<<"the area of rectangle"<<a1;
	    //for area of square
	    int a;
	    cout<<"\nenter the length of side:";
	    cin>>a;
	    a2=a*a;
	    cout<<"the area of square:"<<a2;
	    //area of triangle
	    int l1,h;//l1=length og rectangle ,h=height of rectangle
	    cout<<"\nenter l1:";
	    cin>>l1;
	    cout<<"enter height:";
	    cin>>h;
	    a3=(l1*h)/2;
	    cout<<"area of triangle"<<a3;
	    return 0;
}
