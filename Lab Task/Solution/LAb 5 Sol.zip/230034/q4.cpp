#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    int a,b;//variable  declaration
    cout<<"enter a and b:";
    cin>>a>>b;
    cout<<"Statement"<<setw(30)<<"Result"<<setw(30)<<"Operation";
    cout<<"\nthe and of a & b"<<setw(20)<<(a & b)<<setw(25)<<"&";
    cout<<"\nthe and of a | b"<<setw(20)<<(a | b)<<setw(25)<<"|";
    cout<<"\nthe and of a ^ b"<<setw(20)<<(a ^ b)<<setw(25)<<"^";
}
