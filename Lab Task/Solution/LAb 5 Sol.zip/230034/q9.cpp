#include<iostream>
#include<iomanip>
using namespace std;
int main()
	{
	float w,h,BMI;//w is weight and h is the height
	cout<<"enter weight:";
	cin>>w;
	cout<<"enter height:";
	cin>>h;
	if((h>0)&&(w>0)){
	BMI=w/(h*h);//BMI is the body mass index
	cout<<"\nBMI:"<<BMI;
	if(BMI<18.5){
	cout<<"\n Underweight";
	}
	if((BMI>=18.5)&&(BMI<=24.9)){
	cout<<"\nNormal weight";
	}
	if((BMI>=25)&&(BMI<=29.9)){
	cout<<"\nOverweight";
	}
	if(BMI>=30){
	cout<<"\nObese";
	}
	}
	if((h<=0)||(w<=0))
	{
	cout<<"Invalid input";
	}
	}
