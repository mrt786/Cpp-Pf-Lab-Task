#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    float num1,num2,r;// variable r is the result of num1/num2
    cout<<"enter num1,num2:";
    cin>>num1>>num2;
    if(num2!=0){
    r=num1/num2;
    cout<<setprecision(3)<<r;
    }
    if(num2==0){
    cout<<"Invalid input";
    }
    }

