#include<iostream>
using namespace std;
#include<iomanip>
int main(){
    int a =42;
    cout<<setfill('*')<<setw(8)<< a<<endl;
    a=4242;
    cout<<setfill('*')<<setw(8)<< a<<endl;
    a=424242;
    cout<<setfill('*')<<setw(8)<< a<<endl;
}
