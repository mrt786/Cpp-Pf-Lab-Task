#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    int a;
    cout<<"enter a:";
    cin>>a;;
    cout<<"Statement"<<setw(30)<<"Result"<<"\nComplement of a is:"<<setw(15)<<(~a)<<"\nleft shift of a is"<<setw(16)<<(a<<2)<<"\nRight shift of a is:"<<setw(14)<<(a>>2);
}
