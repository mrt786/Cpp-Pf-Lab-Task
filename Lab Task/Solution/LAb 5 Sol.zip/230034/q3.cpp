#include<iostream>
#include<iomanip>
using namespace std;
int main(){
    cout<<"*\'\n**\\\"\n***\\**\"\n****\\***\'\n***\\***\"\n**\\**\'\n*\\*\"\n*";
}
