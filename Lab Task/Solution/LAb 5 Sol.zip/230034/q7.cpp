#include<iostream>
#include<iomanip>
using namespace std;
int main(){
	int x,y;
	cout<<"Enter x and y:";
	cin>>x>>y;
	cout<<"Result when x multiplies by number"<<setw(14)<<"Result"<<"\nx*2 is:"<<setw(40)<<(x<<1)<<"\nx*4 is:"<<setw(40)<<(x<<2)<<"\nx*8 is:"<<setw(40)<<(x<<3)<<"\nx*4 is:"<<setw(40)<<(x<<4);
	cout<<"\nResult when y divded by a number"<<setw(14)<<"Result"<<"\ny/2 is:"<<setw(40)<<(y>>1)<<"\ny/4 is:"<<setw(40)<<(y>>2)<<"\ny*8 is:"<<setw(40)<<(y>>3)<<"\ny*4 is:"<<setw(40)<<(y>>4);
	}
