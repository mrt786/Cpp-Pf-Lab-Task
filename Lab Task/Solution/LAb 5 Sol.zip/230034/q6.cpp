#include<iostream>
using namespace std;
#include<iomanip>
int main(){
	int a,b=1;
	cout<<"Enter a:";
	cin>>a;
	if((a&b)==1)
	{
	cout<<"\n the numbeer is odd";
	}
	if((a&b)!=1){
	cout<<"\n the number is even";
	}
	}
