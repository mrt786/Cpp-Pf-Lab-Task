#include<iostream>
using namespace std;
#include<iomanip>
int main(){
    int a=1,b=2,c=3;
    cout<<"Number"<< setw(10)<<"Square"<<setw(8)<<"Cube";
    cout<<"\n"<<a<< setw(10)<< a << setw(10) <<a;
    cout<<"\n"<<b<< setw(10)<< b*b << setw(10) <<b*b*b;;
    cout<<"\n"<<c<< setw(10)<<c* c<<setw(11)<<c*c*c;
}
