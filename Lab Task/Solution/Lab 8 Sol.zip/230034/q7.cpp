#include<iostream>
using namespace std;
int main()
{	int num,i;
	cout<<"Enter a positive number";
	cin>>num;
	if(num>0)
	{	i=num*num;
		while(i>0)
		{	cout<<"*";
			i--;
			if(i%num==0)
			{	cout<<endl;
			}
			
		}	
	}
	else 
		cout<<"Entered  number is not positive";	
}
