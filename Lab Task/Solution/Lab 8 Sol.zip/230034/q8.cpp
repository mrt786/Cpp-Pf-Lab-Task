#include<iostream>
using namespace std;
int main()
{	int number,reverseNumber=0,digit;
	cout<<"Enter a positive number";
	cin>>number;
	if(number>0)
	{	while(number!=0)
		{	digit=number%10;
			reverseNumber=(reverseNumber*10)+digit;
			number=number/10;	
		}
		cout<<"The reverse of entered number is:"<<reverseNumber;
	}
	else
		cout<<"Enter a number greater than zero";
}
