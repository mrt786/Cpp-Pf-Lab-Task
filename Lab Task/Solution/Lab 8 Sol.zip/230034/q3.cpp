#include<iostream>
using namespace std;
int main()
{	int amstrongNumber,num1,num2,num3,j=100;
	while(j<=999)
	{
		num1=j/100;
		num2=j%100;
		num2=num2/10;
		num3=j%10;
		num1=num1*num1*num1;
		num2=num2*num2*num2;
		num3=num3*num3*num3;
		amstrongNumber=num1+num2+num3;
		if(amstrongNumber==j)
		{
			cout<<"The amstrong Number between 100-999 is"<<amstrongNumber<<endl;
		}
		j++;
		
	}
	return 0;
	

}
