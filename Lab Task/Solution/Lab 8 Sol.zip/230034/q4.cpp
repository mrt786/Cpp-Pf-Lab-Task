#include<iostream>
using namespace std;
int main()
{	int num,count=0;
	cout<<"Enter a number:";
	cin>>num;
	int i;
	i=num;
	if(num>0)
	{	while(i>=1)
		{	
			if(num%i==0)
				count++;
			i--;
		}
		if(count==2)
			cout<<"You entered a prime number";
		else
			cout<<"Entered number is not a prime";
	}
	else 
	{	cout<<"Invalid number";
		return 0;
	}
}	
