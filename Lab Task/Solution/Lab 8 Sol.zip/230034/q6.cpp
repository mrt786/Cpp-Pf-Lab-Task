#include<iostream>
using namespace std;
int main()
{	int num,fact=1;
	cout<<"Enter a  positive number";
	cin>>num;
	if(num<0)
	{	cout<<"Invalid Number";
	}
	else 
		while(num>0)
		{	
			fact=fact*num;
			num--;
		}
		cout<<"Factorial of entered number is:"<<fact;
	
}
