#include<iostream>
using namespace std;
int main()
{	int num,sum=0;
	cin>>num;
	if(num>0)
	{	while(num>0)
		{	sum=sum+num%10;
			num=num/10;
		}
		cout<<"The sum of the number is:"<<sum;
		
	}
	else
	cout<<"You Enter a negative number";
	return 0;
}
