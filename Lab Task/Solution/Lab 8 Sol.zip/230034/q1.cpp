#include<iostream>
using namespace std;
int main()
{
	int num,i=0,positiveCount=0,negativeCount=0,zeroCount=0;
	while(i<10)
	{	
		cout<<"Enter number:";
		cin>>num;
		if(num==0)
		zeroCount++;
		else if(num>0)
		positiveCount++;
		else 
		negativeCount++;
		i++;
	}	
	cout<<"Total negative Numbers:"<<negativeCount;
	cout<<"\nTotal positive Numbers:"<<positiveCount;
	cout<<"\nTotal zero Numbers:"<<zeroCount;
}

