#include<iostream>
using namespace std;
int min,column_index;
int array_fill(int &n,int &m)
{
	int array[n][m];
	for(int i=0 ;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			cout<<"Enter element to fill the array: ";
			cin>>array[i][j];
		}
	}
	for(int i=0 ;i<n;i++)
	{	int min =array[i][0];//taking the first element of the every row as the minimum element
		column_index=0;
		for(int j=0;j<m;j++)//finding the minimum element in the row
		{
			if(min>array[i][j])
			{
				min=array[i][j];
				column_index=j;
				
			}
		}
		bool ch =true;
		for(int i=0; i<n;i++)
		{
			if(array[i][column_index]>min)// this checkis for if any number in the coolumn is greater than the number that is minimum in its row 
			{
				ch=false;
				break;
			}
		}
		if (ch==false)
		{
			continue;
		}
		else 
		{
			cout<<"the minimum in row "<< i <<" & column: "<< column_index <<"is: "<<min<<endl;
		}
	}
	return 0;
}
int main()
{
	int n,m;
	cout<<"Enter row size: ";
	cin>>n;
	cout<<"Enter column size: ";
	cin>>m;
	array_fill(n,m);
}
