#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    string var,temp="",input;
    char ch;
    int count=1,i=0,j=0;
    cout<<"Enter a string: ";
    getline(cin,var);
    while(var[i]!='\0')
    {
    	if(var[i]==' ')
    	{
    		count++;
    	}
    	i++;
    }
    i=0;
    string array[count];
    while(var[i]!='\0')
    {	
    	ch=var[i];
    	if(ch==' ')
	{
		array[j]+=temp;
		temp="";
		j++;
	}
	else 
	{
		temp+=ch;
	}
	    i++;
    }
    array[j]+=temp;
    int len,sizeOfString;
    i=0;
    while(i<count)
    {   j=0;
        len=array[i].length();///to find the length of a string
        if(len%2!=0)
        {   sizeOfString=len/2;
            string temp=array[i];
            while(j<sizeOfString)
            {
                ch=temp[j];
                temp[j]=temp[len-j-1];
                temp[len-j-1]=ch;
                j++;
            }
            array[i]=temp;
        }
        i++;
    }
    i=0;
    while(i<count)
    {
        cout<<array[i]<<" ";
        i++;
    }
}