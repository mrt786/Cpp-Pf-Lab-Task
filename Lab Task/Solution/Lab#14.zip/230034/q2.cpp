#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    string var,temp="",input;
    char ch;
    int count=1,i=0,j=0;
    cout<<"Enter a string: ";
    getline(cin,var);
    while(var[i]!='\0')
    {
    	if(var[i]==' ')
    	{
    		count++;
    	}
    	i++;
    }
    i=0;
    string array[count];
    while(var[i]!='\0')
    {	
    	ch=var[i];
    	if(ch==' ')
	{
		array[j]+=temp;
		temp="";
		j++;
	}
	else 
	{
		temp+=ch;
	}
	    i++;
    }
    array[j]+=temp;
    cout<<"Enter the String you want to check: \n";
    cin>>input;
    i=0;
    while(i<count)
    {
        if (input==array[i])
        {
            array[i]="";
        }
        i++;
    }
    i=0;
    while(i<count)
    {
        cout<<array[i]<<" ";
        i++;
    }

}