
#include<iostream>
#include<iomanip>
using namespace std;
char grid[3][3]={' ',' ',' ',' ',' ',' ',' ',' ',' ',};
char player;
void game_check();
void draw_game(int row,int column,char player);
bool row_check(char);
bool column_check(char);
bool diagonal_check(char);
int moves=0;
void play_game()
{	while(moves <=9)
		{
		int row,column;
		if(moves%2==0)
		{
			cout<<"Player A Turn your mark is X:\n ";
		}
		else
		{
			cout<<"Player B Turn your mark is O:\n ";
		}
		while(true)
		{	
			cout<<"enter the row [0,2] in which you want your mark: ";
			cin>>row;
			if(row<3)
			{
				break;
			}
		}
		while(true)
		{	
			cout<<"enter the column [0,2] in which you want your mark: ";
			cin>>column;
			if(column<3)
			{
				break;
			}
		}
		if(grid[row][column]!=' ')
		{
			play_game();
		}
		else
		{
			moves++;
		}
		if(moves%2==0)
		{
			player='O';
		}
		else
		{
			player='X';
		}
		draw_game( row,column,player);
	}
}
void draw_game(int row,int column,char player)
{
	grid[row][column]=player;
	cout<<setw(10)<<"  "<<grid[0][0]<<"  "<<"|"<<"  "<<grid[0][1]<<"  "<<"|"<<"  "<<grid[0][2]<<"  "<<"|"<<endl<<setw(10);
	for(int i=1;i<=18;i++)
	{
		cout<<"-";
	}
	cout<<endl;
	cout<<setw(10)<<"  "<<grid[1][0]<<"  "<<"|"<<"  "<<grid[1][1]<<"  "<<"|"<<"  "<<grid[1][2]<<"  "<<"|"<<endl<<setw(10);
		for(int i=1;i<=18;i++)
	{
		cout<<"-";
	}
	cout<<endl;
	cout<<setw(10)<<"  "<<grid[2][0]<<"  "<<"|"<<"  "<<grid[2][1]<<"  "<<"|"<<"  "<<grid[2][2]<<"  "<<"|"<<endl<<endl<<endl;
	game_check();
	
}
void game_over()
{
	char ch;
	cout<<"Player whoose mark is "<<player<<" won \n ";
	cout<<"Enter q to exit the game: ";
	cin>>ch;
	if (ch!='q')
	{
		game_over();
	}
	else 
	{
		exit(0);
	}
}
bool row_check(char Player)
{
	for(int i=0 ;i<3;i++)
	{
		
		if(grid[i][0]==Player && grid[i][1]==Player && grid[i][2]==Player) 
			game_over();
	}
	return true;
}
bool column_check(char Player)
{
	for(int i=0 ;i<3;i++)
	{
		if(grid[0][i]==Player && grid[1][i]==Player && grid[2][i]==Player)
			game_over();
	}
	return true;
}
bool diagonal_check(char Player)
{
	if ((grid[0][0]==Player && grid[1][1]==Player && grid[2][2]==Player) ||(grid[0][2]==Player && grid[1][1]==Player && grid[2][0]==Player))
	{
		game_over();
		return true;
	}
}
void game_check()
{
	if(moves==9)
	{
		cout<<"Game Draw\n";
		char ch;
		cout<<"Enter q to quit the game: ";
		cin>>ch;
		if(ch!='q')
		{
			game_check();
		}
		else 
		{
			exit(0);
		}
	}
	row_check(player);
	column_check(player);
	diagonal_check(player);
	
}

int main()
{
	play_game();
}
