#include<iostream>
using namespace std;
int main()
{
	int row,column,i=0,j=0;
	cout<<"Enter rows: ";
	cin>>row;
	cout<<"Enter column: ";
	cin>>column;
	int col=0;
	int rows=row;
	int midCol=0,midRow=0,sum=0;
	midRow=row/2;
	midCol=column/2;
	int array[row][column];
	for(i=0;i<row;i++)// to input the array
	{	
		for(j=0;j<column;j++)
		{	
			cin>>array[i][j];
		}
	}
	for(i=0;i<row;i++)// to print the arrray
	{	
		for(j=0;j<column;j++)
		{	
			cout<<array[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"Left diagonal: "<<endl;
	for(i=0;i<row;i++)//to print the left diagonal
	{	
		cout<<array[i][i]<<endl;
	}
	cout<<"Right diagonal: "<<endl;
	for(i=0;i<row;i++)//to print the right diagonal
	{	
		cout<<array[i][column-1];
		column--;
		cout<<endl;
	}
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<col;j++)
		{
			if(i==midRow)
			{
				sum+=array[i][j];
			}
			else if(j==midCol)
			{
				sum+=array[i][j];
			}
			
		}
	}
	cout<<"The sum of mid row and mid column is: "<<sum;
}
