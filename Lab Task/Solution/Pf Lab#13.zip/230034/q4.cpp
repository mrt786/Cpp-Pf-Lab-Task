#include<iostream>
using namespace std;
int main()
{
	int i,j,rows;
	cout<<"Enter rows: ";
	cin>>rows;
	int array1[rows][rows],array2[rows][rows],sum=0;
	bool ch=true;
	cout<<"Input first array: "<<endl;
	for(i=0;i<rows;i++)// to input the array
	{	
		for(j=0;j<rows;j++)
		{	
			cin>>array1[i][j];
		}
	}
	cout<<"Input second array: "<<endl;
	for(i=0;i<rows;i++)// to input the array
	{	
		for(j=0;j<rows;j++)
		{	
			cin>>array2[i][j];
		}
	}
	cout<<"Matrix 1:"<<endl;
	for(i=0;i<rows;i++)
	{	
		for(j=0;j<rows;j++)
		{	
			cout<<array1[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"Matrix 2:"<<endl;
	for(i=0;i<rows;i++)
	{	
		for(j=0;j<rows;j++)
		{	
			cout<<array2[i][j]<<" ";
		}
		cout<<endl;
	}
	for(i=0;i<rows;i++)

	{	
		for(j=0;j<rows;j++)
		{	
			if(array1[i][j]!=array2[i][j])//checking the elements of the array
			{
				ch=false;
				break;
			}
		}
	}
	if(ch==false)
	{
		cout<<"The matrices are not equal";
	}
	else
	{
		cout<<"The matrices are equal";
	}
}
