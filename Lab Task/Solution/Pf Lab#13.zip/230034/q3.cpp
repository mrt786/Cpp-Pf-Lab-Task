#include<iostream>
using namespace std;
int main()
{
	int i,j,rows;
	cout<<"Enter rows: ";
	cin>>rows;
	int array1[rows][rows],array2[rows][rows],sum=0;
	cout<<"Input first array: "<<endl;
	for(i=0;i<rows;i++)// to input the array
	{	
		for(j=0;j<rows;j++)
		{	
			cin>>array1[i][j];
		}
	}
	cout<<"Input second array: "<<endl;
	for(i=0;i<rows;i++)// to input the array
	{	
		for(j=0;j<rows;j++)
		{	
			cin>>array2[i][j];
		}
	}
	for(i=0;i<rows;i++)// to input the array
	{	
		for(j=0;j<rows;j++)
		{	
			sum+=array2[i][j]+array1[i][j];
		}
	}
	cout<<"The sum is: "<<sum;
}
