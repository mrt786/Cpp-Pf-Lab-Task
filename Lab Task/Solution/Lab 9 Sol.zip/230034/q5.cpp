#include<iostream>
using namespace std;
int main()
{	int number,sum=0,i;
	cout<<"Enter a number:";
	cin>>number;
	if(number<0)
	{	cout<<"Enter a number greater than zero";
		return 0;
	}
	else
	{
		for(i=number/2;i>0;i--)
		{
			if(number%i==0)
			{	sum=sum+i;
			}
		}
	if(sum==number)
	{	cout<<"Perfect number";
	}
	else
		cout<<"Not a perfect number";
	}
}
