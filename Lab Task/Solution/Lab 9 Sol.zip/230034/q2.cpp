#include<iostream>
using namespace std;
int main()
{	int num1=0,sum=0;
	do
	{
		cout<<"Enter a number";
		sum=sum+num1;
		cin>>num1;
	}
	while(num1>=0);
	cout<<"The sum of the entered numbers is:"<<sum;
}
