#include<iostream>
using namespace std;
int main()
{	int i,n,firstNum=0,secondNum=1,thirdNumber=0;
	cout<<"How many terms you want to print of fibbonacci series:";
	cin>>n;
	if(n>0)
	{	if(n==1)
		{
			cout<<firstNum<<endl;
			return 0;	
		}
		cout<<firstNum<<endl<<secondNum<<endl;
		for(i=0;i<n-2;i++)
		{	
			thirdNumber=firstNum+secondNum;
			firstNum=secondNum;
			secondNum=thirdNumber;
			cout<<thirdNumber<<endl;
		}
	}
	else
	cout<<"Fibonacci series is not less than zero";
}
