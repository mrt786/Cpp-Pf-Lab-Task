#include<iostream>
using namespace std;
int main()
{	int num1,num2,i,j,hcf=1,lcm;
	cout<<"Enter first number:";
	cin>>num1;
	cout<<"Enter 2nd number:";
	cin>>num2;
	if(num1>0 && num2>0)
	{	
		if(num1==num2)
		{	hcf=num1;
			
		}
		else
		{
			for(i=2;i<=num1;i++)
			{	
				for(j=i;j<=num2;j++)
				{	if((num2%j==0)&&(num1%i==0)&&(i==j))
					{
						hcf=i;
					}
				}
			}
		}
		lcm=(num1*num2)/hcf;
		cout<<" The lcm is:"<<lcm;
	}
	
	else
	cout<<"Invlaid input";
}
