#include<iostream>
using namespace std;
#include<cmath>
int main()
{ 	int number,i,sum=0,a;
	cout<<"enter number in binary";
	cin>>number;
	for(i=0;number>0;i++)
	{	
		if(number%10>1)
		{	cout<<"The entered number is not binary";
			return 0;
		}
		else if(number%10==1)
		{	a=pow(2,i);
			sum=a+sum;
			number=number/10;
		}
		else
		{	
			number=number/10;
		}
		
	}
	cout<<"Sum of the binary number:"<<sum;
}
