#include<iostream>
using namespace std;
int main()
{	int rows;
	cout<<"Enter number of rows: ";
	cin>>rows;
	if(rows<0)
		cout<<"Rows cannot be negative";
	else
	{	for(int i=1;i<=rows;i++)
		{	for(int j=1;j<=rows*2+1;j++)
			{	if(i==rows)
					cout<<"*";
				else
				{	cout<<" ";
					if(i==1)
					{	if(j==rows )
						{	cout<<"*";
							j++;
						}
					}
					else
					{
						if(j==rows-i || j==rows+i)
						{
							cout<<"*";
							j++;
						}
					}
					
				}	
			}
			cout<<endl;
		}
	}
}
