#include<iostream>
using namespace std;
int main()
{	int rows,loop1,loop2;
	cout<<"Enter number of rows: ";
	cin>>rows;
	if(rows<0)
		cout<<"Rows cannot be negative";
	else
	{	for(loop1=0;loop1<rows;loop1++)
		{	for(loop2=loop1;loop2>0;loop2--)
			{	cout<<loop2;
			}
			for(int loop3=0;loop3<rows-loop1;loop3++)
			{	cout<<loop3;
			}
			cout<<endl;
		}
		
	}
}
