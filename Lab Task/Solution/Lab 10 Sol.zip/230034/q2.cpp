#include<iostream>
using namespace std;
int main()
{	int rows;
	char ch='A',result;
	cout<<"Enter number of rows: ";
	cin>>rows;
	if(rows<0)
		cout<<"Rows cannot be negative";
	else
	{	
		for(int i=1;i<=rows;i++)
		{	int j=0;
			while(j<i)
			{	result=ch+(char)j;
				cout<<result;
				j++;
			}
			cout<<endl;
		}
	}
}
