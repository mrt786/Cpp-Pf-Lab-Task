#include<iostream>
#include<iomanip>
using namespace std;
int main()
{	 int rows,loop1=1,loop2=0;
	cout<<"Enter number of rows: ";
	cin>>rows;
	if(rows<0)
		cout<<"Rows cannot be negative";
	else
	{	for(int i=0; i<=rows;i++)	
		{	for(int j=1;j<=i;j++)
				{	for(int k=0; k<j;k++)
					{	
						cout<<"*";
					}
					cout<<endl;
				}
			cout<<endl;
		}
	}
}
