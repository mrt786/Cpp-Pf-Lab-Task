#include<iostream>
#include<iomanip>
using namespace std;
int main()
{	int rows,loop1=1,loop2=0;
	cout<<"Enter number of rows: ";
	cin>>rows;
	if(rows<0)
		cout<<"Rows cannot be negative";
	else
	{	
		while(loop1<=rows)
		{	if(loop1==(rows/2)+1)
			{	for(loop2=1;loop2<=rows;loop2++)
					cout<<loop2<<" ";
			}	
			else
				cout<<setw(rows)<<loop1;
			cout<<endl;
			loop1++;		
		}
	}
}
