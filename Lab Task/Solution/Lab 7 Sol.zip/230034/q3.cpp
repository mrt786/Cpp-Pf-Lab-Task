#include<iostream>
using namespace std;
int main(){
	int num1=10,num2=20;
	cout<<"Number before swapping are num1="<<num1<<"\nnum2"<<num2;
	num1=num1^num2;
	num2=num1^num2;
	num1=num1^num2;
	cout<<"\nNumbers after swapping are num1="<<num1<<"\nnum2="<<num2;
	}
