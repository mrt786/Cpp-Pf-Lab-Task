#include<iostream>
using namespace std;
int main()
{	int number,originalNumber,difference,reversedNumber;
	cout<<"Enter a number:";
	cin>>originalNumber;
	number=originalNumber;
	if(number>=100000000 && number<=999999999)
	{	reversedNumber=((number%10)*100000000);
		number=number/10;
		reversedNumber=reversedNumber+((number%10)*10000000);
		number=number/10;
		reversedNumber=reversedNumber+((number%10)*1000000);
		number=number/10;
		reversedNumber=reversedNumber+((number%10)*100000);
		number=number/10;
		reversedNumber=reversedNumber+((number%10)*10000);
		number=number/10;
		reversedNumber=reversedNumber+((number%10)*1000);
		number=number/10;
		reversedNumber=reversedNumber+((number%10)*100);
		number=number/10;
		reversedNumber=reversedNumber+((number%10)*10);
		number=number/10;
		reversedNumber=reversedNumber+(number%10);
		cout<<"\nReverse of number="<<reversedNumber;
		difference=originalNumber-reversedNumber;
		if(difference>0)
			cout<<"\nOriginal number is"<<difference<<"step bigger:";
		else if(difference==0)
			cout<<"\nBoth numbers are equal; hence it is a palindrome";
		else
		{	difference=difference*(-1);
			cout<<"\nReversed Number is"<<difference<<"step bigger:";
		}
	}
	else
		cout<<"\nInvalid input";
	
}
