#include<iostream>// bit input, num>>bit-1  num&1 ==1 on 
using namespace std;
int main()
{	int bitNumber,number,onOff;
	cout<<"Enter a number:";
	if(cin>>number)
	{	cout<<"Enter bitnumber in the range of 0-32:";
		cin>>bitNumber;
		if(bitNumber>0 && bitNumber<=32)
		{	onOff=(number>>(bitNumber-1));
			if((onOff&1)==1)
				cout<<"Bit is on";
			else
				cout<<"Bit is off";
		}
		else 
		cout<<"Bit number is not in the range";
	}
	else
	cout<<"Number is not in the range of short";
}

