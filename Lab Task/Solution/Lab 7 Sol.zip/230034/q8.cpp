#include<iostream>
using namespace std;
int main(){
	int number1,number2;
	cout<<"enter a number=";
	if(cin>>number1)
	{	number2=(number1^1);
		cout<<number2;
		if(number2>number1)
			cout<<"\nThe number is even";
		else
			cout<<"\nThe number is odd";
	}
	else
		cout<<"\n Invalid input";
	}
