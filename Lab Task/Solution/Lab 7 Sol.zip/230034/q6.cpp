#include<iostream>
using namespace std;
int main()
{
	char number1,number2,number3,number4,number5;
	cout<<"Enter a character Range[0-9]";
	cin>>number1>>number2>>number3>>number4>>number5;
	if(number1>=48 && number1<=57)
		if(number2>=48 && number2<=57)
			if(number3>=48 && number3<=57)
				if(number4>=48 && number4<=57)
					if(number5>=48 && number5<=57)
					{	number1=((int)number1)-48;
						number2=((int)number2)-48;
						number3=((int)number3)-48;
						number4=((int)number4)-48;
						number5=((int)number5)-48;
						int sum=number1+number2+number3+number4+number5;
						cout<<"THE SUM OF FIVE NUMBERS IS:"<<sum;
					}
					else
						cout<<"number5 is not in the range";
				else
					cout<<"number4 is not in the range";
			else
				cout<<"number3 is not in the range";
		else
			cout<<"number2 is not in the range";
	else
		cout<<"\nnumber 1 is not in the range";
}
