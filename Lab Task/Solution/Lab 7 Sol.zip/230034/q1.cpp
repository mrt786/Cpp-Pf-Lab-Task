#include<iostream>
using namespace std;
int main(){
	int startingDayNumber,nightsStay,weekday;
	cout<<"Menu of the days is \n1.MONDAY\n2.TUESDAY\n3.WEDNESDAY\n4.THURSDAY\n5.FRIDAY\n6.SATURDAY\n7.SUNDAY";
	cout<<"\nEnter the starting day number:";
	cin>>startingDayNumber;
	cout<<"Enter the nights of stay:";
	cin>>nightsStay;
	if(startingDayNumber>0 && startingDayNumber<8 && nightsStay>0)
	{	weekday=nightsStay+startingDayNumber;
		weekday=weekday%7;
		switch(weekday)
		{	case 0:
			cout<<"SUNDAY";
			break;
			case 1:
			cout<<"MONDAY";
			break;
			case 2:
			cout<<"TUESDAY";
			break;
			case 3:
			cout<<"WEDNESDAY";
			break;
			case 4:
			cout<<"THURSDAY";
			break;
			case 5:
			cout<<"FRIDAY";
			break;
			case 6:
			cout<<"SATURDAY";
			break;
		}
	}
	else
	cout<<"Invalid Input";
}
