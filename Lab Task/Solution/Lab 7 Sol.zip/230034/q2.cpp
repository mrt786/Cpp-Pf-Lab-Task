#include<iostream>
using namespace std;
int main()
{	int temperature;
	cout<<"Enter temperature in celcius";
	if(cin>>temperature)
	{	if(temperature<0)
		cout<<"Freezing Weather";
		else
			temperature=temperature/10;
			switch(temperature)
			{	case 0:
					cout<<"very cold weather";
					break;
				case 1:
					cout<<"cold weather";
					break;
				case 2:
					cout<<"Normal in Temperature";
					break;
				case 3:
					cout<<"Normal in temperature";
					break;
				default:
					cout<<"Very hot";
					break;
			}
	}
	else
	cout<<"\nenter temperature in integer";	
}
