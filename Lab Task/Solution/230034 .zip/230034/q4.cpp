#include<iostream>
using namespace std;
int main()
{
	int a[8],number,count=0;
	for(int i=0;i<8; i++)
	{
		cin>>a[i];
	}
	cout<<"Enter the number which you want to equal to the sum of numbers: ";
	cin>>number;
	for(int i=0;i<8-1;i++)
	{	
		for(int j=i+1;j<8;j++)
		{	
			if(a[i]+a[j]==number)
			{
				cout<<a[i]<<" "<<a[j]<<endl;
				count++;
			}
		}
	}
	cout<<"The parirs whose sum is equal to"<<number<<":"<<count;
}
