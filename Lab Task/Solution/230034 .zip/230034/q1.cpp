#include<iostream>
using namespace std;
int main()
{
	int array[7]={4,5,12,9,22,45,7},temp=0;
	for(int i=0;i<7;i++)
	{
		for(int j=0;j<i;j++)
		{	if(array[i]<=array[i+1] && array[i]>=array[i-1])
			{
				
				temp=array[i];
				array[i]=array[i+1];
				array[i+1]=temp;
				cout<<array[i];
			}
		}
		cout<<array[i];
	}
}
