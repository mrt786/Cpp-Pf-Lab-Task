#include<iostream>
using namespace std;
int main()
{
	int a[10],sum=0,maxSum=0,startIndex=0,endIndex=0;
	for(int i=0;i<10;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<10;i++)
	{	sum=0;
		for(int j=i;j<i+2;j++)
		{
			sum+=a[i];
		}
		if(sum>maxSum)
		{
			startIndex=i-2;
			endIndex=i;
			maxSum=sum;	
		}
	}
	cout<<"Maximum sum array: ["<<a[startIndex]<<","<<a[endIndex-1]<<","<<a[endIndex]<<"]"<<"Sum:"<<sum<<" StartIndex: "<<startIndex<<" EndIndex: "<<endIndex;
}
