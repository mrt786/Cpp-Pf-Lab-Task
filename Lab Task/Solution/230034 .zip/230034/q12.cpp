#include<iostream>
using namespace std;
int main()
{	int size,count=0;
	cout<<"The size of array: ";
	cin>>size;
	char a[size],b[size];
	for(int i=0;i<size;i++)
	{
		cin>>a[i];
	}
	for(int i=size-1,j=0;i>=0;i--)
	{
		b[j]=a[i];
		j++;
	}
	for(int i=0;i<size;i++)
	{
		if(b[i]==a[i])
		{
			count++;
		}
	}
	if(count==size)
		cout<<"\n IT is a palindrome";
	else
		cout<<"\n not is a palindrome";
}
