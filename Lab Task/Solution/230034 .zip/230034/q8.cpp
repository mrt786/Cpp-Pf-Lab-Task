#include<iostream>
using namespace std;
int main()
{
	int k;
	int a[5],b[5],union[k],intersection[5];
	for(int i=0;i<5;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<5;i++)
	{
		cin>>b[i];
	}	
	for(int i=0;i<5;i++)
	{	for(int j=i;j<number;j++)
		{
				if(a[i]==a[j] && a[i]!=)
				{	
					intersection[5]=a[i];
				}
		}
	}
}
