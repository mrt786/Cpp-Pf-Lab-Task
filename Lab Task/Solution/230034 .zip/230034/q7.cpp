#include<iostream>
using namespace std;
int main()
{	int temp=0,number;
	cout<<"Enter the size of array: ";
	cin>>number;
	int a[number];
	for(int i=0;i<number;i++)
	{
		cin>>a[i];
	}	
	for(int i=0;i<number-1;i++)
	{	for(int j=i+1;j<number;j++)
		{
				if(a[i]==a[j] && a[i]!=temp)
				{	
					temp=a[i];
					cout<<temp;
				}
		}
	}
}
