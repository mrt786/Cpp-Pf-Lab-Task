#include<iostream>
using namespace std;
int main()
{
	int a[6],step=0,j=0,temp=0;
	for(int i=0;i<6;i++)
	{
		cout<<"Enter array: ";
		cin>>a[i];
	}
	cout<<"Enter steps you want to rotate the array: ";
	cin>>step;
	for(int i=0;i<step;i++)
	{
		temp=a[i];
		a[i]=a[i+step];
		a[i+step]=temp;
	}
	for(int i=0;i<6;i++)
	{

		cout<<a[i];
	}
}
