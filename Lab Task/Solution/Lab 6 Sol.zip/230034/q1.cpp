#include<iostream>
using namespace std;
int main(){
	char character;
	cout<<"enter a character\n";
	cin>>character;
	if((character>='A'&&character<='Z')||(character>='a'&&character<='z'))
		{if((character=='a'||character=='e'||character=='i'||character=='o'||character=='u')||(character=='A'||character=='E'||character=='I'||character=='O'||character=='U'))
			cout<<"\n you entered a vowel";	
		else
			cout<<"\nyou entered a consonant";
		cout<<"a";
		}
	else
		cout<<"\n You entered an invalid input";	
	}

