#include <iostream>
using namespace std;

int main()
{	float rate,unit,tax,bill;
	cout<<"Enter number of units \n";
	if(cin>>unit)
		if(unit>=0)
		{
			if(unit<100)
			{	
				rate=9;
			}
			else if(unit>=100&&unit<200)
			{	
				rate=11;
			}
			else if(unit>=200&& unit<300)
			{
				rate=9;
			}
			else
				cout<<"Too many units";	
				bill=rate*unit;
			if(bill<750)
			{	
				tax=0.05*bill;
				bill=bill+tax;
				cout<<"\n Your bill is:"<<bill;
			}
			else
			{
				tax=0.07*750;
				bill=bill+tax;
				cout<<bill;
			}
		}	
		else 
		cout<<"\nInvalid units";					
	else
		cout<<"Invalid datatype";
}
	
	
	
	
	
	
	
	
	
	
