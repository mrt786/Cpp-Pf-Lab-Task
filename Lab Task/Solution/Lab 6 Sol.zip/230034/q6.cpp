#include<iostream>
using namespace std;
int main(){
	int score;
	cout<<"Enter the score\n";
	if(cin>>score)
		if(score>=0 && score<=100)
			switch(score/10){
				case 10:
				case 9:
					cout<<"\nA";
					break;
				case 8:
					cout<<"\nB";
					break;
				case 7:
					cout<<"\nC";
					break;
				case 6:
					cout<<"\nD";
					break;
				default:
					cout<<"\nF";	
					break;
					}
		else
			cout<<"\ninvalid output";
	else
		cout<<"\ninvalid input";
	}
