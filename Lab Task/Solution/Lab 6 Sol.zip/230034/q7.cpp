#include<iostream>
using namespace std;
int main()
{	int num1,num2;
	float result;
	char Operator;
	cout<<"enter operator\n";
	if(cin>>Operator)
		if(Operator=='+'||Operator=='-'||Operator=='*'||Operator=='/')
			if(cin>>num1 && cin>>num2)
				{
				switch(Operator)
					{
						case '+':
							result=num1+num2;
							cout<<"\n Addition o f two number is:"<<result;
						case '/':
						if(num2==0)
						{
							cout<<"\n num2 cannot be zero";
							break;
						}	
						else
							result=num1/num2;
							cout<<"\nDivision of two numbers is:"<<result;
							break;
						case '-':
							result =num1-num2;
							cout<<"\nthe result of subtraction of two no's is:"<<result;
							break;
						case '*':
							result =num1*num2;
							cout<<"\nthe multiplication of two nos:"<<result;
							break;						
				}}
			else
			cout<<"\ninvalid data type";
		else
			cout<<"\nInvalid operator";
	else
	cout<<"\nInvalid data type";

}
