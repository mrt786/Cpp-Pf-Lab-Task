#include<iostream>
using namespace std;
#include<string.h>
int main()
{
	int year;
	cout<<"enter the year"<<endl;
	if(cin>>year)
		if (year>0)
			if(year>0 && year<100){
				if(year%4==0)
					cout<<"leap year";
			}
				else
				{	if (year%100!=1){
						if(year%400==0)
							cout<<"it is a leap year";
						else
							cout<<"not a leap year";
							}
					else
						cout<<"Not a leap year";
				}
	else 
		cout<<"invalid input";
			
		else 
			cout<<"invalid input";
			
}			
