#include<iostream>
using namespace std;
int main(){
	int noOfDays;
	double fee;
	cout<<"enter no of days"<<endl;
	if(cin>>noOfDays)
		{if(noOfDays>=1){
			if(noOfDays>=1 && noOfDays<=7){
				fee=noOfDays*0.25;
				cout<<"\nYour book is overdue and your fee is:"<<fee;
				}
			else if(noOfDays>=8 && noOfDays<=14){
				noOfDays=noOfDays-7;
				fee=noOfDays*0.5;
				fee=7*0.25+fee;
				cout<<"\nYour book is overdue and your fee is:"<<fee;
				}
			else if(noOfDays>=15 && noOfDays<=30){
				noOfDays=noOfDays-7;
				fee=noOfDays*1;
				fee=7*0.25+7*0.5+fee;
				cout<<"\nYour book is overdue and your fee is:"<<fee;
				}	
			else 
				{
				noOfDays=noOfDays-30;
				fee=noOfDays*2;
				fee=7*0.25+7*0.5+16*1+fee;
				cout<<"\nYour book is overdue and your fee is:"<<fee;}
				}
			
		else
			cout<<"invalid input";}
	
	else
	cout<<"invlaid input";
	}
