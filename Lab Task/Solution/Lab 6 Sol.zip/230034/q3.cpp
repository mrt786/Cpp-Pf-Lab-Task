#include<iostream>
using namespace std;
int main(){
	int totalNumberOfClasses,classesAttend; 
	cout<<"ente the total no of classes and classes you attends\n";
	if(cin>>totalNumberOfClasses&&cin>>classesAttend){
		if(totalNumberOfClasses>0 && classesAttend<=totalNumberOfClasses && classesAttend>=0){
			float percentage;
			percentage=(classesAttend/(float)totalNumberOfClasses)*100;
			if(percentage>85)
				cout<<"\n Your attendence is:"<<percentage<<"%"<<endl<<"You are allowed to sit in the exam";
			else
				cout<<"\n Your attendence is less than 85% and you're not allowed to sit in the exam ";}
		else 
			cout<<"invalid input";}
	else 
		cout<<"Invalid input";
		
	}
