#include<iostream>
using namespace std;
int main()
{	float timetaken;
	cout<<"enter time taken\n";
		if(cin>>timetaken)
			if (timetaken>0)
				if(timetaken>=1 && timetaken<2)
					cout<<"\n You're highly efficient";
				else if(timetaken>=2 && timetaken<3)
					cout<<"\n improve your training speed";
				else if(timetaken>=3 && timetaken<4)
					cout<<"\n You have given training to iprove your speed";
				else if(timetaken>=4 && timetaken<5)
					cout<<"\nIssue a final waring letter";
				else
					cout<<"\n leave the company";
			else
			cout<<"\n Invalid time";	
		else 
			cout<<"\nInvalid  date type of time";
			
			
}
